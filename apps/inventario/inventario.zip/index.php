<?php
//Si bahy consulta

// echo __FILE__.'>dd.....<br>';
if (file_exists("config/accesosystems.php")) {
    include("config/accesosystems.php");
} else {
    if (file_exists("../config/accesosystems.php")) {
        include("../config/accesosystems.php");
    } else {
        if (file_exists("../../config/accesosystems.php")) {
            include("../../config/accesosystems.php");
        }
    }
}


//echo $p; //viene con el modulo activo

// //echo base_url.'.......<br>'.'...'.hostname.','.db_login.','.db_pass.','.bbserver1.'----<br>';
$conetar = new mysqli(hostname, db_login, db_pass, cw3ctrlsrv);
if ($conetar->connect_errno) {
    $error = "Fallo al conectar a MySQL: (" . $conetar->connect_errno . ") " . $conetar->connect_error;
    echo $error;
} else {

    include('reglasdenavegacion.php');
    $nmbapp = "INVENTARIO";
    $moduraiz = $_SESSION['moduraiz'];
    $ruta =  "<a href='#'>Home</a> / " . $moduraiz;
    $uppercaseruta = strtoupper($ruta);
    // echo $sctrl1;
   

    //echo ".................".$sctrl4."-----------";
    $cadena = "SELECT count(*) as cantidad
                    FROM  u116753122_cw3completa.bodegaubcproducto";
    //              echo $cadena;
    $resultadP2 = $conetar->query($cadena);
    $filaP2 = mysqli_fetch_array($resultadP2);
    $cantrgt = $filaP2['cantidad'];;
?>

    <div class="card border-light">

        <div class="table-title" style="padding: 30px;">
            <div class="row">
                <div class="col-md-4">
                    <div class="">
                        <nav class="breadcrumbs">
                            <a href="#" class="breadcrumbs__item" style="text-decoration: none;"><?php echo $moduraiz; ?></a>
                            <a href="#" class="breadcrumbs__item is-active" style="text-decoration: none;">Inventario</a>
                        </nav>
                        <!--<label class="card-title" style="color: rgb(1,103,183);font-size: 13px;float: right;"><strong><?php echo $uppercaseruta; ?></strong> </label>-->
                    </div>
                </div>
                <div class="col-md-4" style="text-align: center; padding: 10px">
                    <h4><strong>Listado de Inventario</strong></h4>
                </div>
            
            </div>
        </div>

        <div class="card-body">
            <div class="row">
                <div class="col-md-12 col-lg-12">
                    <div id="thetable" name="thetable" style="overflow:hidden;  margin-bottom:5px; border-bottom:thin dotted #d3d3d3;
                                           height:auto;width:100%;"></div><?php //aqui va thedatatable.php //tabla de la app 
                                                                            ?>
                 
                </div>
                
            </div>
        </div>
    </div>

    <?php


    include('apps/thedata.php'); //scriops de control
    ?>

    <script>
        $(document).ready(function() {


            $('#thetable').load('https://cw3.tierramontemariana.org/apps/inventario/tabla.php');



        })
    </script>
<?php
}
?>