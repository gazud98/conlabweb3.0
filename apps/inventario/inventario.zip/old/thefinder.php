

    <div class="modal fade" id="modal-find" style="display: none;" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Busqueda</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <div class="modal-body">


                        <div class="row">
                            <div class="col-md-12 col-lg-12">
                                <label style="font-size: 12px;">Codigo</label>
                                <input type="input" class="form-control" style="width: 100%; height: 28px;font-size: 12px;"></input>
                            </div>
                            <div class="col-md-12 col-lg-12">
                                <label style="font-size: 12px;">Descripcion</label>
                                <input type="input" class="form-control" style="width: 100%; height: 28px;font-size: 12px;"></input>
                            </div>
                        </div>


            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <button type="button" class="btn btn-primary">Aplicar</button>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
     </div>






