<?php if (file_exists("config/accesosystems.php")) {
    include("config/accesosystems.php");
} else {
    if (file_exists("../config/accesosystems.php")) {
        include("../config/accesosystems.php");
    } else {
        if (file_exists("../../config/accesosystems.php")) {
            include("../../config/accesosystems.php");
        }
    }
} // echo __FILE__.'>dd.....<br>';

//echo $p; //viene con el modulo activo

// //echo base_url.'.......<br>'.'...'.hostname.','.db_login.','.db_pass.','.bbserver1.'----<br>';
$conetar = new mysqli(hostname, db_login, db_pass, cw3ctrlsrv);
if ($conetar->connect_errno) {
    $error = "Fallo al conectar a MySQL: (" . $conetar->connect_errno . ") " . $conetar->connect_error;
    echo $error;
} else {
?>
    <div id="upload">
        <?php

        // Verifica si el archivo fue cargado correctamente sin errores

        // Especifica la ubicación donde deseas guardar el archivo
        $directorio_destino = "https://cw3.tierramontemariana.org/appsdata/producto/"; // Cambia 'carpeta_destino' por la ruta deseada
        $directorio ="https://cw3.tierramontemariana.org/appsdata/producto/";
        // Obtiene el nombre y la ruta temporal del archivo cargado
        $nombre_archivo = $_FILES["archivo"]["name"];
        $ruta_temporal = $_FILES["archivo"]["tmp_name"];
        $id = $_GET['id'];
        $ruta_completa = $directorio_destino . $nombre_archivo;
        // Mueve el archivo desde la ubicación temporal al destino
        if (file_exists($ruta_completa)) {
            echo "El archivo ya existe.";
        } else  if (move_uploaded_file($ruta_temporal, $ruta_completa)) {
            echo "El archivo ha sido cargado correctamente.";
            $sql = "INSERT INTO u116753122_cw3completa.productos_archivo (id_producto,nombre_archivo, ruta)VALUES ('" . $id . "','" . $nombre_archivo . "', '" . $directorio . "')";

            $rest = mysqli_query($conetar, $sql);
        } else {
            echo "Ocurrió algún error al subir el fichero. No pudo guardarse.";
        }



        ?>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {

            function cargar() {
                $('#upload').load('https://cw3.tierramontemariana.org/apps/producto/form-files.php?id=<?php echo $id ?>');
            }
          

        });
    </script>
<?php } ?>