<?php
$result = "err";
//     presntadio n par todos lod produtos tipo ACTVOS FIJOS

if (file_exists("config/accesosystems.php")) {
    include("config/accesosystems.php");
} else {
    if (file_exists("../config/accesosystems.php")) {
        include("../config/accesosystems.php");
    } else {
        if (file_exists("../../config/accesosystems.php")) {
            include("../../config/accesosystems.php");
        }
    }
}

// echo __FILE__.'>dd.....<br>';

//echo $p; //viene con el modulo activo

// //echo base_url.'.......<br>'.'...'.hostname.','.db_login.','.db_pass.','.bbserver1.'----<br>';
$conetar = new mysqli(hostname, db_login, db_pass, cw3ctrlsrv);
if ($conetar->connect_errno) {
    $error = "Fallo al conectar a MySQL: (" . $conetar->connect_errno . ") " . $conetar->connect_error;
    echo $error;
} else {


    include('reglasdenavegacion.php');


    //genera elos procesos de crud al formulario del directorio dond eesoy ubicado
    $fchhora = date('m-d-Y h:i:s a', time());

    $modeeditstatus = $_REQUEST['modeeditstatus1'];
    $id = $_REQUEST['id'];
    if ($modeeditstatus == "D") { //es de desahibilitar/habikitr
        //          si estadio es 1 pasa ra 0 o v iceversa
        $cadena = "select estado from u116753122_cw3completa.producto where id_producto='" . $id . "'";
        $resultadP2a = $conetar->query($cadena);
        $numerfiles2a = mysqli_num_rows($resultadP2a);
        if ($numerfiles2a >= 1) {
            $filaP2a = mysqli_fetch_array($resultadP2a);
            $estado = trim($filaP2a['estado']);
        } else {
            $estado = '1';
        }
        if ($estado == '1') {
            $estado = '0';
        } else {
            $estado = '1';
        }
        $cadena = "update u116753122_cw3completa.producto set estado='" . $estado . "' where id_producto='" . $id . "'";
        $resultado = mysqli_query($conetar, $cadena);
        $result = "ok";
    } else { //es crea o moifica

        $id_categoria_producto = $_POST['id_categoria_producto']; //esa ctivo fijo
        $nombre = trim($_POST['nombre']);
        $referencia = trim($_POST['referencia']);
        $id_departamento = trim($_POST['id_departamento']);
        //$id_sede = trim($_POST['id_sede']);
        $estado = trim($_POST['estado']);
        $iva = trim($_POST['iva']);
        date_default_timezone_set('America/Bogota');
        $fechaActual = date('d-m-Y');
        $fecha = $fechaActual;
        $hora = date("h:i:s");
        $fechafinal = $fecha . " " . $hora;


        if ($id_categoria_producto == "3") { //produtos
            $iva = trim($_POST['iva']);
            //$tipprod = trim($_POST['tipprod']);
            $cantidad_presentacion = trim($_POST['cantidad_presentacion']);
            $id_presentacion = trim($_POST['id_presentacion']);
            $cantidad_unidadmedida = trim($_POST['cantidad_unidadmedida']);
            $id_unidadmedida = trim($_POST['id_unidadmedida']);
            //$id_clasificacion_riesgo = trim($_POST['id_clasificacion_riesgo']);
            //$nombre_imagen = trim($_POST['nombre_imagen']);
            //$id_bodegas = trim($_POST['id_bodegas']);
            $id_departamento = trim($_POST['id_departamento']);
            $stckmin = trim($_POST['stckmin']);
            $stckpntoreorden = trim($_POST['stckpntoreorden']);
            $stckmax = trim($_POST['stckmax']);
            //$csmoprommes = trim($_POST['csmoprommes']);
            //$id_condicion_almacenaje = trim($_POST['id_condicion_almacenaje']);
            $cod_contable = trim($_POST['cod_contable']);
            //$categoria = trim($_POST['categoria']);
            //$pactivo = trim($_POST['pactivo']);
            //$ffarmaceutica = trim($_POST['ffarmaceutica']);
            $vida_util = trim($_POST['vida_util']);
            $lote = trim($_POST['lote']);
            $marca = trim($_POST['marca']);
            $serie = trim($_POST['serie']);
            //$fvence = trim($_POST['fvence']);
            //$concentracion = trim($_POST['concentracion']);
            //$reg_invima = trim($_POST['reg_invima']);


            if ($modeeditstatus == "C") { ////CREACION
                $cadena = "insert into u116753122_cw3completa.producto(id_categoria_producto,nombre,referencia,id_departamento,
                                    cantidad_presentacion,id_presentacion,cantidad_unidadmedida,id_unidadmedida,
                                    stckmin,stckpntoreorden,stckmax,cod_contable,vida_util,
                                    lote,marca,serie,iva,tipo_prod
                                )values('" . $id_categoria_producto . "','" . $nombre . "','" . $referencia . "','" . $id_departamento . "','" .
                    $cantidad_presentacion . "','" . $id_presentacion . "','" . $cantidad_unidadmedida . "','" . $id_unidadmedida . "','" .
                    $stckmin . "','" . $stckpntoreorden . "','" . $stckmax . "','" . $cod_contable . "','" . $vida_util . "','" . $lote . 
                    "','" . $marca . "','" . $serie . "','" . $iva . "','P')";


                echo $cadena;
                $resultado = mysqli_query($conetar, $cadena);
                $result = "ok";
            } else {

                $cadena = "update u116753122_cw3completa.producto set
                                id_categoria_producto='" . $id_categoria_producto . "',
                                nombre='" . $nombre . "',
                                referencia='" . $referencia . "',
                                id_departamento='" . $id_departamento . "',
                                cantidad_presentacion='" . $cantidad_presentacion . "',
                                id_presentacion='" . $id_presentacion . "',
                                cantidad_unidadmedida='" . $cantidad_unidadmedida . "',
                                id_unidadmedida='" . $id_unidadmedida . "',
                                stckmin='" . $stckmin . "',
                                stckpntoreorden='" . $stckpntoreorden . "',
                                stckmax='" . $stckmax . "',
                                cod_contable='" . $cod_contable . "',
                                vida_util='" . $vida_util . "',
                                lote='" . $lote . "',
                                marca='" . $marca . "',
                                serie='" . $serie . "',
                                iva='" . $iva . "'
                            where id_producto='" . $id . "'";
                $resultado = mysqli_query($conetar, $cadena);
                $result = "ok";
            } //De inserccion

        } //de proxucos
        //...............................................................................................................................................................
    } //es de desahibilitar/habikitr
}
