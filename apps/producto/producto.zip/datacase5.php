<?php
//     presntadio n par todos lod produtos tipo insumo
if (file_exists("config/accesosystems.php")) {
    include("config/accesosystems.php");
} else {
    if (file_exists("../config/accesosystems.php")) {
        include("../config/accesosystems.php");
    } else {
        if (file_exists("../../config/accesosystems.php")) {
            include("../../config/accesosystems.php");
        }
    }
}

// echo __FILE__.'>dd.....<br>';

//echo $p; //viene con el modulo activo

// //echo base_url.'.......<br>'.'...'.hostname.','.db_login.','.db_pass.','.bbserver1.'----<br>';
$conetar = new mysqli(hostname, db_login, db_pass, cw3ctrlsrv);
if ($conetar->connect_errno) {
    $error = "Fallo al conectar a MySQL: (" . $conetar->connect_errno . ") " . $conetar->connect_error;
    echo $error;
} else {


    include('reglasdenavegacion.php');

    //echo '..............................'.$_REQUEST['id'].'...';
    if (isset($_REQUEST['id'])) {
        $id = $_REQUEST['id'];
        if ($id == "-1") {
            $id = "";
        }
    } else {
        $id = "";
    }

    //$id=1;
    // echo $caso.'----'.$id;
    /* */
    $id_categoria_producto = "5"; //es un Insumo
    $referencia = "";
    $nombre = "";
    $id_departamento = "";
    $estado = "";
    $cantidad_presentacion = "";
    $id_presentacion = "";
    $cantidad_unidadmedida = "";
    $id_unidadmedida = "";
    $id_clasificacion_riesgo = "";
    $nombre_imagen = "";

    $id_departamento = "";
    $stckmin = "";
    $stckpntoreorden = "";
    $stckmax = "";
    $csmoprommes = "";
    $id_condicion_almacenaje = "";
    $categoria = "";
    $principio_activo =  "";
    $forma_farmaceutica =  "";
    $vida_util =  "";
    $lote =  "";
    $marca = "";
    $serie =  "";
    $fecha_vencimiento =  "";
    $concentracion =  "";
    $reg_invima =  "";



    if ($id != "") {
        $cadena = "select P.id_producto,P.referencia,P.id_categoria_producto,P.nombre,id_departamento,P.estado,
                        P.cantidad_presentacion,P.id_presentacion,P.cantidad_unidadmedida,P.id_unidadmedida,
                        P.id_clasificacion_riesgo,P.nombre_imagen,P.id_bodegas,P.id_departamento,
                        P.stckmin,P.stckpntoreorden,P.stckmax,P.csmoprommes,P.id_condicion_almacenaje,P.categoria,P.principio_activo,P.forma_farmaceutica,
                        P.vida_util,P.lote,P.marca,P.serie,P.fecha_vencimiento,P.concentracion,P.reg_invima
                    from u116753122_cw3completa.producto P
                    where P.id_producto='" . $id . "'";
        //                 echo $cadena;
        $resultadP2 = $conetar->query($cadena);
        $numerfiles2 = mysqli_num_rows($resultadP2);
        if ($numerfiles2 >= 1) {
            $filaP2 = mysqli_fetch_array($resultadP2);
            $id = trim($filaP2['id_producto']);
            $id_categoria_producto = "5";
            $referencia = trim($filaP2['referencia']);
            $nombre = trim($filaP2['nombre']);
            $id_departamento = trim($filaP2['id_departamento']);
            $estado = trim($filaP2['estado']);
            $cantidad_presentacion = trim($filaP2['cantidad_presentacion']);
            $id_presentacion = trim($filaP2['id_presentacion']);
            $cantidad_unidadmedida = trim($filaP2['cantidad_unidadmedida']);
            $id_unidadmedida = trim($filaP2['id_unidadmedida']);
            $id_clasificacion_riesgo = trim($filaP2['id_clasificacion_riesgo']);

            $id_departamento = trim($filaP2['id_departamento']);
            $stckmin = trim($filaP2['stckmin']);
            $stckpntoreorden = trim($filaP2['stckpntoreorden']);
            $stckmax = trim($filaP2['stckmax']);
            $csmoprommes = trim($filaP2['csmoprommes']);
            $id_condicion_almacenaje = trim($filaP2['id_condicion_almacenaje']);
            $categoria = trim($filaP2['categoria']);
            $principio_activo = trim($filaP2['principio_activo']);
            $forma_farmaceutica = trim($filaP2['forma_farmaceutica']);
            $vida_util = trim($filaP2['vida_util']);
            $lote = trim($filaP2['lote']);
            $marca = trim($filaP2['marca']);
            $serie = trim($filaP2['serie']);
            $fecha_vencimiento = trim($filaP2['fecha_vencimiento']);
            $concentracion = trim($filaP2['concentracion']);
            $reg_invima = trim($filaP2['reg_invima']);
        }
    }


?>

    <style>
        .formcontrol {
            display: block;
            width: 100%;
            padding: 2px;
            font-size: 11px;
            line-height: 1.5;
            color: #495057;
            background-color: #fff;
            background-clip: padding-box;
            border: 1px solid #C3C3C3 !important;
            border-radius: 0.25rem;
            box-shadow: inset 0 0 0 rgba(0, 0, 0, 0);
            transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
        }

        .table-txt-insu {
            width: 100%;
        }

        .table-txt-insu tr,
        tr td {
            width: 100px;
            padding-left: 10px;
        }
    </style>

    <form class="form-group form-insu" name="formcontrol" id="formcontrol" action="" method="POST" enctype="multipart/form-data" style="width:100%">
        <input type="hidden" name="modeeditstatus" id="modeeditstatus" value="">
        <input type="hidden" name="id_categoria_producto" id="id_categoria_producto" value="5">
        <input type="hidden" name="estado" id="estado" value="<?php echo $estado; ?>">

        <div class="row mb-2">
            <div class="col-md-3 col-lg-3 ">
                <?php
                if ($id != "") {
                    $parametroacodificar = "Codigo: " . $id . "\nReferencia: " . $referencia . "\nNombre: " . $nombre;
                    include('../../apps/genqr.php');
                } else {
                    echo '<i class="fa-solid fa-qrcode" style="font-size: 60px; color: #9EAFB9;"></i>';
                }
                ?>
            </div>
            <div class="col-md-9 col-lg-9 ">
                <div class="row mb-2">

                    <table class="table-txt-insu">
                        <tbody>
                            <tr>
                                <td style="background-color: #fff; border-radius:10px; font-size:18px;">
                                    <label style="font-size: 11px;">Codigo:</label>
                                    
                                        <input type="input" class="formcontrol" 
                                        style=" 
                                        text-align: center;
                                        font-weight: 900;
                                        font-size: 20px;
                                        " 
                                        readonly name="id" id="id" value="<?php echo $id; ?>"></input>
    
                                </td>
                                <td>
                                    <label style="font-size: 11px;">Referencia:</label>
                                    <input type="input" class="formcontrol" name="referencia" name="referencia" id="referencia" value="<?php echo $referencia; ?>"></input>
                                    <?php if ($estado == '0') {
                                        echo "<span style='color:red;'> Inhabilitado</span>";
                                    } ?>

                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label style="font-size: 11px;">Nombre:</label>
                                    <input type="input" class="formcontrol" name="nombre" id="nombre" value="<?php echo $nombre; ?>"></input>
                                </td>
                                <td>
                                    <label style="font-size: 11px;">Departamento</label>
                                    <select class="formcontrol" name="id_departamento" id="id_departamento">
                                        <option selected="true" disabled="disabled"></option>
                                        <?php
                                        $cadena = "SELECT id, nombre
                                                    FROM u116753122_cw3completa.departamentos
                                                    where estado='1'";
                                        $resultadP2a = $conetar->query($cadena);
                                        $numerfiles2a = mysqli_num_rows($resultadP2a);
                                        if ($numerfiles2a >= 1) {
                                            while ($filaP2a = mysqli_fetch_array($resultadP2a)) {
                                                echo "<option value='" . trim($filaP2a['id']) . "'";
                                                echo '>' . $filaP2a['nombre'] . "</option>";
                                            }
                                        }
                                        ?>
                                    </select>
                                    <div id="id_departamentox"></div>
                                </td>
                            </tr>
                        </tbody>
                    </table>

                </div>

            </div>
        </div>

        <div class="row mb-2">
            <div class="col-md-12 col-lg-12">
                <div class="row">
                    <table class="table-txt-insu">
                        <tbody>
                            <tr>
                                <td>
                                    <label style="font-size: 11px;">Unidad:</label>
                                    <input type="input" class="formcontrol" name="cantidad_unidadmedida" id="cantidad_unidadmedida" value="<?php echo $cantidad_unidadmedida; ?>"></input>
                                    <div id="cantidad_unidadmedidax"></div>
                                </td>
                                <td>
                                    <label style="font-size: 11px; margin-bottom:2px;"></label><br>
                                    <select class="formcontrol" name="id_unidadmedida" id="id_unidadmedida">
                                        <option selected="true" disabled="disabled"></option>
                                        <?php
                                        $cadena = "SELECT um.id,um.nombre, um.simbolo
                                                            FROM u116753122_cw3completa.unidad_medida um
                                                            where um.estado='1'";
                                        $resultadP2a = $conetar->query($cadena);
                                        $numerfiles2a = mysqli_num_rows($resultadP2a);
                                        if ($numerfiles2a >= 1) {
                                            while ($filaP2a = mysqli_fetch_array($resultadP2a)) {
                                                echo "<option value='" . trim($filaP2a['id']) . "'";
                                                echo '>' . $filaP2a['nombre'] . "</option>";
                                            }
                                        }
                                        ?>
                                    </select>
                                    <div id="id_unidadmedidax"></div>
                                </td>
                                <td>
                                    <label style="font-size: 11px;">Presentacion:</label>
                                    <input type="input" class="formcontrol" name="cantidad_presentacion" id="cantidad_presentacion" value="<?php echo $cantidad_presentacion; ?>"></input>
                                    <div id="cantidad_presentacionx"></div>
                                </td>
                                <td>
                                    <label style="font-size: 11px;"></label>
                                    <select class="formcontrol" name="id_presentacion" id="id_presentacion">
                                        <option selected="true" disabled="disabled"></option>
                                        <?php
                                        $cadena = "SELECT UM.id,UM.nombre
                                                        FROM u116753122_cw3completa.unidad_medida UM
                                                        where estado='1'";
                                        $resultadP2a = $conetar->query($cadena);
                                        $numerfiles2a = mysqli_num_rows($resultadP2a);
                                        if ($numerfiles2a >= 1) {
                                            while ($filaP2a = mysqli_fetch_array($resultadP2a)) {
                                                echo "<option value='" . trim($filaP2a['id']) . "'";
                                                echo '>' . $filaP2a['nombre'] . "</option>";
                                            }
                                        }
                                        ?>
                                    </select>
                                    <div id="id_presentacionx"></div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="row" style="border:thin dotted gray">

            <table class="table-txt-insu">
                <tr>
                    <td>
                        <label style="font-size: 11px;">Stock Minimo:</label><br>
                        <input type="input" class="formcontrol" name="stckmin" id="stckmin" value="<?php echo $stckmin; ?>"></input>
                        <div id="stckminx"></div>
                    </td>
                    <td>
                        <label style="font-size: 11px;">Punto de Reorden:</label><br>
                        <input type="input" class="formcontrol" name="stckpntoreorden" id="stckpntoreorden" value="<?php echo $stckpntoreorden; ?>"></input>
                        <div id="stckpntoreordenx"></div>
                    </td>
                    <td>
                        <label style="font-size: 11px;">Stock Maximo:</label><br>
                        <input type="input" class="formcontrol" name="stckmax" id="stckmax" value="<?php echo $stckmax; ?>"></input>
                        <div id="stckmaxx"></div>
                    </td>
                    <td>
                        <label style="font-size: 11px;">Consumo :</label><br>
                        <input type="input" class="formcontrol" name="csmoprommes" id="csmoprommes" readonly value="<?php echo $csmoprommes; ?>"></input>
                        <div id="csmoprommesx"></div>
                    </td>
                    <?php
                    $cadenax =  "SELECT MIN(fchvence) as fchvence 
                    FROM u116753122_cw3completa.bodegaubcproducto 
                    where idproducto = '" . $id . "' and identrepanio <>0";

                    $resultadP2ax = $conetar->query($cadenax);
                    $numerfiles2ax = mysqli_num_rows($resultadP2ax);
                    if ($numerfiles2ax >= 1) {
                        while ($filaP2ax = mysqli_fetch_array($resultadP2ax)) {
                            $fchvence = trim($filaP2ax['fchvence']);
                        }
                    } else {
                        $fchvence = "";
                    }
                    ?>
                    <td>
                        <label style="font-size: 11px;">F. Vence Producto en Bodega:</label>
                        <input type="date" class="formcontrol" name="fvence" id="fvence" value="<?php echo $fchvence; ?>"></input>
                    </td>
                </tr>
            </table>
        </div>

        <div class="row mt-2">

            <table class="table-txt-insu">
                <tr>
                    <td>
                        <label style="font-size: 11px;">Nivel de Riesgo:</label>
                        <select class="formcontrol" aria-label="Default select example" name="id_clasificacion_riesgo" id="id_clasificacion_riesgo">
                            <option selected="true" disabled="disabled"></option>
                            <?php
                            $cadena = "SELECT id_clasificacion_riesgo, descripcion
                                                    FROM u116753122_cw3completa.clasificacion_riesgo
                                                    where estado='1'";
                            $resultadP2a = $conetar->query($cadena);
                            $numerfiles2a = mysqli_num_rows($resultadP2a);
                            if ($numerfiles2a >= 1) {
                                while ($filaP2a = mysqli_fetch_array($resultadP2a)) {
                                    echo "<option value='" . trim($filaP2a['id_clasificacion_riesgo']) . "'";
                                    echo '>' . $filaP2a['descripcion'];
                                    echo "</option>";
                                }
                            }
                            ?>
                        </select>
                        <div id="id_clasificacion_riesgox"></div>
                    </td>
                    <td>
                        <label style="font-size: 11px;">Condiciones de Almacenamiento:</label>
                        <select class="formcontrol" aria-label="Default select example" name="id_condicion_almacenaje" id="id_condicion_almacenaje">
                            <option selected="true" disabled="disabled"></option>
                            <?php
                            $cadena = "SELECT id_condicion_almacenaje, descripcion
                                                    FROM u116753122_cw3completa.condicion_almacenaje
                                                    where estado='1'";
                            $resultadP2a = $conetar->query($cadena);
                            $numerfiles2a = mysqli_num_rows($resultadP2a);
                            if ($numerfiles2a >= 1) {
                                while ($filaP2a = mysqli_fetch_array($resultadP2a)) {
                                    echo "<option value='" . trim($filaP2a['id_condicion_almacenaje']) . "'";
                                    echo '>' . $filaP2a['descripcion'];
                                    echo "</option>";
                                }
                            }
                            ?>
                        </select>
                        <div id="id_condicion_almacenajex"></div>
                    </td>
                    <td>
                        <label style="font-size: 11px;">Categoria:</label>
                        <select class="formcontrol" aria-label="Default select example" name="categoria" id="categoria">
                            <option selected="true" disabled="disabled"></option>
                            <option value="1">Insumos</option>
                            <option value="2">Equipos Biomedicos</option>
                            <option value="3">Muebles y Enseres</option>
                            <option value="4">Reactivos</option>
                            <option value="5">No Aplica</option>
                        </select>
                        <div id="categoriax"></div>
                    </td>
                    <td>
                        <label style="font-size: 11px;">Principio Activo:</label>
                        <input type="input" class="formcontrol" name="pactivo" id="pactivo" value="<?php echo $principio_activo; ?>"></input>
                        <div id="pactivox"></div>
                    </td>
                    <td>
                        <label style="font-size: 11px;">Forma Farmaceutica:</label>
                        <input type="input" class="formcontrol" name="ffarmaceutica" id="ffarmaceutica" value="<?php echo $forma_farmaceutica; ?>"></input>
                        <div id="ffarmaceuticax"></div>
                    </td>
                </tr>
            </table>
        </div>

        <div class="row mt-2">

            <table class="table-txt-insu">

                <tr>
                    <td>
                        <label style="font-size: 11px;">Vida Util:</label>
                        <input type="input" class="formcontrol" name="vida_util" id="vida_util" value="<?php echo $vida_util; ?>"></input>
                        <div id="vida_utilx"></div>
                    </td>
                    <td>
                        <label style="font-size: 11px;">Lote:</label>
                        <input type="input" class="formcontrol" name="lote" id="lote" value="<?php echo $lote; ?>"></input>
                        <div id="lotex"></div>
                    </td>
                    <td>
                        <label style="font-size: 11px;">Marca:</label>
                        <input type="input" class="formcontrol" name="marca" id="marca" value="<?php echo $marca; ?>"></input>
                        <div id="marcax"></div>
                    </td>
                    <td>
                        <label style="font-size: 11px;">Serie:</label>
                        <input type="input" class="formcontrol" name="serie" id="serie" value="<?php echo $serie; ?>"></input>
                        <div id="seriex"></div>
                    </td>
                    <td>
                        <label style="font-size: 11px;">Fecha Vencimiento:</label>
                        <input type="date" class="formcontrol" name="fvence2" id="fvence2" value="<?php echo $fecha_vencimiento; ?>"></input>
                        <div id="fvencex"></div>
                    </td>
                </tr>

            </table>

        </div>

        <div class="row mt-2">

            <table class="table-txt-insu">

                <tr>
                    <td>
                        <label style="font-size: 11px;">Concentracion:</label>
                        <input type="input" class="formcontrol" name="concentracion" id="concentracion" value="<?php echo $concentracion; ?>"></input>
                        <div id="concentracionx"></div>
                    </td>
                    <td>
                        <label style="font-size: 11px;">Registro Invima:</label>
                        <input type="input" class="formcontrol" name="reginvima" id="reginvima" value="<?php echo $reg_invima; ?>"></input>
                        <div id="reginvimax"></div>
                    </td>
                </tr>

            </table>
        </div>
        <div class="row mb-2">

            <div class="col-md-6 col-lg-6 " style="display: none;">
                <label style="font-size: 11px;margin-left:15px;">
                    Fecha Creación 23/02/2023
                </label>
            </div>
        </div>


    </form>

    <?php //del div de proveedores rtelaciondos 
    ?>


<?php
}
?>

<script>
    $(document).ready(function() {
        $('#successbtn').click(function() {
            var referencia = $('#referencia').val();
            var nombre = $('#nombre').val();
            var id_departamento = $('#id_departamento').val();
            var cantidad_unidadmedida = $('#cantidad_unidadmedida').val();
            var id_unidadmedida = $('#id_unidadmedida').val();
            var cantidad_presentacion = $('#cantidad_presentacion').val();
            var id_presentacion = $('#id_presentacion').val();
            //  var stckmin = $('#stckmin').val();
            //var stckpntoreorden = $('#stckpntoreorden').val();
            //  var stckmax = $('#stckmax').val();
            var id_clasificacion_riesgo = $('#id_clasificacion_riesgo').val();
            var id_condicion_almacenaje = $('#id_condicion_almacenaje').val();
            var categoria = $('#categoria').val();
            var pactivo = $('#pactivo').val();
            var ffarmaceutica = $('#ffarmaceutica').val();
            var vida_util = $('#vida_util').val();
            var lote = $('#lote').val();
            var marca = $('#marca').val();
            var serie = $('#serie').val();
            var fvence2 = $('#fvence2').val();
            var concentracion = $('#concentracion').val();
            var reginvima = $('#reginvima').val();

            if (id_departamento == null) {
                id_departamento = '';
            }
            if (id_unidadmedida == null) {
                id_unidadmedida = '';
            }
            if (id_presentacion == null) {
                id_presentacion = '';
            }
            if (id_clasificacion_riesgo == null) {
                id_clasificacion_riesgo = '';
            }
            if (id_condicion_almacenaje == null) {
                id_condicion_almacenaje = '';
            }
            if (categoria == null) {
                categoria = '';
            }
            if (referencia.trim() === '') {
                $("#referencia").css("border", "thin solid red");
                $("#referenciax").html("<span style='color:red; font-size: 14px;font-family: 'Open Sans';'>Este campo no puede estar vacío.</span>");
                return;
            } else {
                $("#referencia").css("border", "thin solid rgb(233,236,239)");
                $("#referenciax").empty();
            }
            if (nombre.trim() === '') {
                $("#nombre").css("border", "thin solid red");
                $("#nombrex").html("<span style='color:red; font-size: 14px;font-family: 'Open Sans';'>Este campo no puede estar vacío.</span>");
                return;
            } else {
                $("#nombre").css("border", "thin solid rgb(233,236,239)");
                $("#nombrex").empty();
            }

            if (id_departamento.trim() === '') {
                $("#id_departamento").css("border", "thin solid red");
                $("#id_departamentox").html("<span style='color:red; font-size: 14px;font-family: 'Open Sans';'>Este campo no puede estar vacío.</span>");
                return;
            } else {
                $("#id_departamento").css("border", "thin solid rgb(233,236,239)");
                $("#id_departamentox").empty();
            }

            if (cantidad_unidadmedida.trim() === '') {
                $("#cantidad_unidadmedida").css("border", "thin solid red");
                $("#cantidad_unidadmedidax").html("<span style='color:red; font-size: 14px;font-family: 'Open Sans';'>Este campo no puede estar vacío.</span>");
                return;
            } else {
                $("#cantidad_unidadmedida").css("border", "thin solid rgb(233,236,239)");
                $("#cantidad_unidadmedidax").empty();
            }

            if (id_unidadmedida.trim() === '') {
                $("#id_unidadmedida").css("border", "thin solid red");
                $("#id_unidadmedidax").html("<span style='color:red; font-size: 14px;font-family: 'Open Sans';'>Este campo no puede estar vacío.</span>");
                return;
            } else {
                $("#id_unidadmedida").css("border", "thin solid rgb(233,236,239)");
                $("#id_unidadmedidax").empty();
            }

            if (cantidad_presentacion.trim() === '') {
                $("#cantidad_presentacion").css("border", "thin solid red");
                $("#cantidad_presentacionx").html("<span style='color:red; font-size: 14px;font-family: 'Open Sans';'>Este campo no puede estar vacío.</span>");
                return;
            } else {
                $("#cantidad_presentacion").css("border", "thin solid rgb(233,236,239)");
                $("#cantidad_presentacionx").empty();
            }
            if (id_presentacion.trim() === '') {
                $("#id_presentacion").css("border", "thin solid red");
                $("#id_presentacionx").html("<span style='color:red; font-size: 14px;font-family: 'Open Sans';'>Este campo no puede estar vacío.</span>");
                return;
            } else {
                $("#id_presentacion").css("border", "thin solid rgb(233,236,239)");
                $("#id_presentacionx").empty();
            }

            /*if (stckmin.trim() === '') {
                $("#stckmin").css("border", "thin solid red");
                $("#stckminx").html("<span style='color:red; font-size: 14px;font-family: 'Open Sans';'>Este campo no puede estar vacío.</span>");
                return;
            } else {
                $("#stckmin").css("border", "thin solid rgb(233,236,239)");
                $("#stckminx").empty();
            }

            if (stckpntoreorden.trim() === '') {
                $("#stckpntoreorden").css("border", "thin solid red");
                $("#stckpntoreordenx").html("<span style='color:red; font-size: 14px;font-family: 'Open Sans';'>Este campo no puede estar vacío.</span>");
                return;
            } else {
                $("#stckpntoreorden").css("border", "thin solid rgb(233,236,239)");
                $("#stckpntoreordenx").empty();
            }
            if (stckmax.trim() === '') {
                $("#stckmax").css("border", "thin solid red");
                $("#stckmaxx").html("<span style='color:red; font-size: 14px;font-family: 'Open Sans';'>Este campo no puede estar vacío.</span>");
                return;
            } else {
                $("#stckmax").css("border", "thin solid rgb(233,236,239)");
                $("#stckmaxx").empty();
            }*/

            collapseanshow('A');
        });

    });

    $(document).ready(function() {
        $('#cancelbtn').click(function() {
            $("#referencia").css("border", "thin solid rgb(233,236,239)");
            $("#referenciax").empty();
            $("#nombre").css("border", "thin solid rgb(233,236,239)");
            $("#nombrex").empty();
            $("#id_departamento").css("border", "thin solid rgb(233,236,239)");
            $("#id_departamentox").empty();
            $("#cantidad_unidadmedida").css("border", "thin solid rgb(233,236,239)");
            $("#cantidad_unidadmedidax").empty();
            $("#id_unidadmedida").css("border", "thin solid rgb(233,236,239)");
            $("#id_unidadmedidax").empty();
            $("#cantidad_presentacion").css("border", "thin solid rgb(233,236,239)");
            $("#cantidad_presentacionx").empty();
            $("#id_presentacion").css("border", "thin solid rgb(233,236,239)");
            $("#id_presentacionx").empty();
            /*       $("#stckmin").css("border", "thin solid rgb(233,236,239)");
                   $("#stckminx").empty();
                   $("#stckpntoreorden").css("border", "thin solid rgb(233,236,239)");
                   $("#stckpntoreordenx").empty();
                   $("#stckmax").css("border", "thin solid rgb(233,236,239)");
                   $("#stckmaxx").empty();*/
         
        });
    });
</script>