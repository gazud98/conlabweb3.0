<?php
//     presntadio n par todos lod produtos tipo producro en genral
if (file_exists("config/accesosystems.php")) {
    include("config/accesosystems.php");
} else {
    if (file_exists("../config/accesosystems.php")) {
        include("../config/accesosystems.php");
    } else {
        if (file_exists("../../config/accesosystems.php")) {
            include("../../config/accesosystems.php");
        }
    }
}

// echo __FILE__.'>dd.....<br>';

//echo $p; //viene con el modulo activo

// //echo base_url.'.......<br>'.'...'.hostname.','.db_login.','.db_pass.','.bbserver1.'----<br>';
$conetar = new mysqli(hostname, db_login, db_pass, cw3ctrlsrv);
if ($conetar->connect_errno) {
    $error = "Fallo al conectar a MySQL: (" . $conetar->connect_errno . ") " . $conetar->connect_error;
    echo $error;
} else {


    include('reglasdenavegacion.php');

    //echo '..............................'.$_REQUEST['id'].'...';
    if (isset($_REQUEST['id'])) {
        $id = $_REQUEST['id'];
        if ($id == "-1") {
            $id = "";
        }
    } else {
        $id = 0;
    }
    $GLOBALS['id'] = $id;

    //$id=1;
    // echo $caso.'----'.$id;
    /* */
    $id_categoria_producto = "3"; //es un PRODUCTO
    $referencia = "";
    $nombre = "";
    $id_departamento = "";
    $estado = "";
    $cantidad_presentacion = "";
    $id_presentacion = "";
    $cantidad_unidadmedida = "";
    $id_unidadmedida = "";
    $id_clasificacion_riesgo = "";
    $nombre_imagen = "";
    $id_bodegas = "";
    $id_departamento = "";
    $stckmin = "";
    $stckpntoreorden = "";
    $stckmax = "";
    $csmoprommes = "";
    //$id_condicion_almacenaje = "";
    $cod_contable = "";
    $categoria = "";
    $principio_activo =  "";
    $forma_farmaceutica =  "";
    $vida_util =  "";
    $lote =  "";
    $marca = "";
    $serie =  "";
    $fecha_vencimiento =  "";
    $concentracion =  "";
    $reg_invima =  "";
    $tipo_prod =  "";
    $iva =  "";
    if ($id != 0) {
        $cadena = "select P.id_producto,P.referencia,P.id_categoria_producto,P.nombre,id_departamento,P.estado,
                        P.cantidad_presentacion,P.id_presentacion,P.cantidad_unidadmedida,P.id_unidadmedida,
                        P.id_clasificacion_riesgo,P.nombre_imagen,P.id_bodegas,P.id_departamento,
                        P.stckmin,P.stckpntoreorden,P.stckmax,P.csmoprommes,P.id_condicion_almacenaje,P.cod_contable,P.categoria,P.principio_activo,P.forma_farmaceutica,
                        P.vida_util,P.lote,P.marca,P.serie,P.fecha_vencimiento,P.concentracion,P.reg_invima,P.tipo_prod,P.iva
                    from u116753122_cw3completa.producto P
                    where P.id_producto='" . $id . "'";
        //                 echo $cadena;
        $resultadP2 = $conetar->query($cadena);
        $numerfiles2 = mysqli_num_rows($resultadP2);
        if ($numerfiles2 >= 1) {
            $filaP2 = mysqli_fetch_array($resultadP2);
            $id = trim($filaP2['id_producto']);
            $id_categoria_producto = "3"; //es un producto
            $referencia = trim($filaP2['referencia']);
            $nombre = trim($filaP2['nombre']);
            $id_departamento = trim($filaP2['id_departamento']);
            $estado = trim($filaP2['estado']);
            $cantidad_presentacion = trim($filaP2['cantidad_presentacion']);
            $id_presentacion = trim($filaP2['id_presentacion']);
            $cantidad_unidadmedida = trim($filaP2['cantidad_unidadmedida']);
            $id_unidadmedida = trim($filaP2['id_unidadmedida']);
            $id_clasificacion_riesgo = trim($filaP2['id_clasificacion_riesgo']);
            $nombre_imagen = trim($filaP2['nombre_imagen']);
            $id_bodegas = trim($filaP2['id_bodegas']);
            $id_departamento = trim($filaP2['id_departamento']);
            $stckmin = trim($filaP2['stckmin']);
            $stckpntoreorden = trim($filaP2['stckpntoreorden']);
            $stckmax = trim($filaP2['stckmax']);
            $csmoprommes = trim($filaP2['csmoprommes']);
            $id_condicion_almacenaje = trim($filaP2['id_condicion_almacenaje']);
            $cod_contable = trim($filaP2['cod_contable']);
            $categoria = trim($filaP2['categoria']);
            $principio_activo = trim($filaP2['principio_activo']);
            $forma_farmaceutica = trim($filaP2['forma_farmaceutica']);
            $vida_util = trim($filaP2['vida_util']);
            $lote = trim($filaP2['lote']);
            $marca = trim($filaP2['marca']);
            $serie = trim($filaP2['serie']);
            $fecha_vencimiento = trim($filaP2['fecha_vencimiento']);
            $concentracion = trim($filaP2['concentracion']);
            $reg_invima = trim($filaP2['reg_invima']);
            $tipo_prod = trim($filaP2['tipo_prod']);
            $iva = trim($filaP2['tipo_prod']);
        }
    }


?>

    <style>
        .formcontrol {

            width: 100%;

            height: 1.8rem;


        }

        .table-txt-order {
            width: 100%;
        }

        .table-txt-order tr,
        tr td {
            width: 80px;
            padding-left: 10px;
        }
    </style>

    <div name="formcontrol" id="formcontrol" action="" method="POST" enctype="multipart/form-data" style="
    width:100%;
    padding: 0px 30px 10px  30px; ">
        <input type="hidden" name="modeeditstatus" id="modeeditstatus" value="">
        <input type="hidden" name="id_categoria_producto" id="id_categoria_producto" value="3">
        <input type="hidden" name="estado" id="estado" value="<?php echo $estado; ?>">

        <div class="row">

            <table class="table-txt-tip" style="width:100%;">
                <tr>
                    <td>
                        <div id="tp" style="text-align:center;">
                            <label style="font-size: 13px;">Seleccione Producto o Equipo:</label>
                            <select class="form-control" style="height: 1.5rem;font-size: 12px;" onchange="changeProducto(this)">
                                <option selected="true" disabled="disabled"></option>
                                <option value="I" <?php if ($tipo_prod == "I") {
                                                        echo "selected";
                                                    } ?>>Equipos</option>
                                <option value="P" <?php if ($tipo_prod == "P") {
                                                        echo "selected";
                                                    } ?>>Productos</option>
                            </select>
                        </div>
                    </td>
                </tr>
            </table>
        </div>

        <div id="choose-producto">


        </div>



    </div>



<?php
}
?>

<script>
    $(document).ready(function() {
        $("#modeeditstatus").change(function() {
            var status = $("#modeeditstatus").val();
            $("#modeeditstatus1").val(status);
        });
    });

    function changeProducto(sel) {
        var prd = $('option:selected', sel).attr('value');
        var status = 'C';
        var estado = $("#estado").val();

        if (prd == 'I') {
            $("#choose-producto").load("https://cw3.tierramontemariana.org/apps/producto/equipos.php", {
                status: status,
                estado: estado
            }, function(response, status, xhr) {
                // Este código se ejecutará después de que la carga esté completa
                if (status === "success") {
                    // Código adicional que deseas ejecutar después de cargar
                    $("#btones").css("display", "block");
                } else {
                    // Manejar errores si es necesario
                    console.log("Error cargando contenido.");
                }
            });
        } else if (prd == 'P') {
            $("#choose-producto").load("https://cw3.tierramontemariana.org/apps/producto/productos.php", {
                status: status,
                estado: estado
            }, function(response, status, xhr) {
                // Este código se ejecutará después de que la carga esté completa
                if (status === "success") {
                    // Código adicional que deseas ejecutar después de cargar
                    $("#btones").css("display", "block");
                } else {
                    // Manejar errores si es necesario
                    console.log("Error cargando contenido.");
                }
            });
        }

    }
</script>